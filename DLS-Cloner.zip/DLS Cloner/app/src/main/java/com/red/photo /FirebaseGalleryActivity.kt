package com.red.photo

import android.app.AlertDialog
import android.os.Bundle
import android.widget.EditText
import android.widget.GridView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.storage.FirebaseStorage

class FirebaseGalleryActivity : AppCompatActivity() {

    private lateinit var gridView: GridView
    private val imageUrls = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gallery)

        gridView = findViewById(R.id.grid_view)

        // Step 1: Ask for passkey before loading images
        promptForPasskey()
    }

    private fun promptForPasskey() {
        val editText = EditText(this)
        editText.hint = "Enter 10-digit passkey"

        AlertDialog.Builder(this)
            .setTitle("🔒 Access Protected")
            .setMessage("Please enter the passkey to view cloned photos:")
            .setView(editText)
            .setCancelable(false)
            .setPositiveButton("Unlock") { dialog, _ ->
                val input = editText.text.toString()
                if (input == "9814540634") {
                    fetchImagesFromFirebase()
                } else {
                    Toast.makeText(this, "❌ Wrong passkey!", Toast.LENGTH_LONG).show()
                    finish() // close activity
                }
            }
            .show()
    }

    private fun fetchImagesFromFirebase() {
        val storageRef = FirebaseStorage.getInstance().reference.child("cloned_photos")

        storageRef.listAll()
            .addOnSuccessListener { listResult ->
                imageUrls.clear()
                for (item in listResult.items) {
                    item.downloadUrl.addOnSuccessListener { uri ->
                        imageUrls.add(uri.toString())

                        // Refresh adapter every time a new image is added
                        val adapter = ImageAdapter(this, imageUrls)
                        gridView.adapter = adapter
                    }.addOnFailureListener {
                        Toast.makeText(this, "❌ Failed to load an image.", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .addOnFailureListener {
                Toast.makeText(this, "⚠️ Failed to access Firebase Storage", Toast.LENGTH_LONG).show()
            }
    }
}