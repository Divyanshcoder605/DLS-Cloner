package com.red.photo

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.storage.FirebaseStorage
import java.io.File

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val cloneButton = findViewById<Button>(R.id.btn_clone)
        val viewButton = findViewById<Button>(R.id.btn_view)

        cloneButton.setOnClickListener {
            uploadAllPhotosToFirebase()
        }

        viewButton.setOnClickListener {
            startActivity(Intent(this, FirebaseGalleryActivity::class.java))
        }
    }

    private fun uploadAllPhotosToFirebase() {
        val storageRef = FirebaseStorage.getInstance().reference.child("cloned_photos")
        val dir = File(Environment.getExternalStorageDirectory().absolutePath + "/DCIM/Camera")
        if (dir.exists()) {
            val files = dir.listFiles()
            files?.forEach { file ->
                val uri = Uri.fromFile(file)
                val photoRef = storageRef.child(file.name)
                photoRef.putFile(uri)
            }
        }
    }
}